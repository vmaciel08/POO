package Exceptions;

public class CarroJaAlocadoException extends Exception {

	public CarroJaAlocadoException() {
		super("Carro j� alocado!");
	}
}