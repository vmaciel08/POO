package Exceptions;

public class CarroNaoCadastradoException extends Exception {
	
	public CarroNaoCadastradoException() {
		super("Carro n�o cadastrado!");
	}
}
