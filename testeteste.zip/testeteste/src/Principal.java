
import Exceptions.CarroCadastradoException;
import Exceptions.CarroException;
import Exceptions.CarroJaAlocadoException;
import Exceptions.CarroNaoCadastradoException;
import Exceptions.UsuarioCadastradoException;
import Exceptions.UsuarioException;
import Exceptions.UsuarioNaoCadastradoException;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vitória
 */
public class Principal {
	public static void main(String[] args) {
		int opcao;// Variável para pecorrer as opções.
		boolean achei; // Varável para encontrar as exeções
		boolean acheiUsuario = false;
		boolean acheiCarro = false;
		Usuario usuario = new Usuario();

		String guardar; // Variável para guardar elementos

		ArrayList<Usuario> listaUsuario = new ArrayList<>();
		ArrayList<Carro> listaCarro = new ArrayList<>();
		do {
			do {
				opcao = Integer.parseInt(JOptionPane.showInputDialog("" + "MENU DE OPÇÕES\n" + "\n 1 - Manter Usuario"
						+ "\n 2 - Manter Carro" + "\n 3 - Pesquisar Usuario" + "\n 4 - Pesquisar Carro"
						+ "\n 5 - Realizar Locação" + "\n 6 - Devolver Carro"
						+ "\n 7 - Relatorio de Locações Por Usuário" + "\n 8 - Sair"));
			} while (opcao < 1 || opcao > 8);

			switch (opcao) {

			case 1:
				int opcoesManterUsuario = Integer.parseInt(JOptionPane.showInputDialog(
						"" + "1 - Cadastar Usuario:" + "\n2 - Editar Usuario:" + "\n3 - Excluir Usuario:"));

				switch (opcoesManterUsuario) {
				case 1:
					// --------------------CADASTRO----------------------------------------------
					Usuario u = new Usuario(); // Criando usuario
					u.setNome(JOptionPane.showInputDialog("Digite o nome do Usuario: "));
					u.setCpf(JOptionPane.showInputDialog("Digite o cpf do Usuario: "));
					u.setEndereco(JOptionPane.showInputDialog("Digite o endereço do Usuario: "));
					u.setContato(JOptionPane.showInputDialog("Digite o contato do Usuario: "));
					for (int i = 0; i < listaUsuario.size(); i++) {
						try {
							while (listaUsuario.get(i).getCpf().equals(u.getCpf())) {
								throw new UsuarioCadastradoException();// Lançando a exeção
							}
						} catch (UsuarioCadastradoException e) { // Tratando a exeção
							JOptionPane.showMessageDialog(null, e.getMessage());
							u.setCpf(JOptionPane.showInputDialog("Digite outro cpf: "));
						}
					}

					listaUsuario.add(u);
					break;
				// ----------------------------FIM DE
				// CADASTRO------------------------------------------
				// ------------------------------EDIÇÃO-----------------------------------------
				case 2:
					achei = false;
					guardar = (JOptionPane.showInputDialog("Digite o cpf do Usuario que quer editar: "));
					int opcaoEditar = Integer.parseInt(JOptionPane.showInputDialog(
							"Digite o que você quer editar: " + "\n1 - Nome" + "\n2- Endereço" + "\n3-Contato"));
					if (opcaoEditar == 1) {
						try {
							for (int i = 0; i < listaUsuario.size(); i++) {
								if (listaUsuario.get(i).getCpf().equals(guardar)) {
									listaUsuario.get(i).setNome(JOptionPane.showInputDialog("Digite o novo nome: "));
									JOptionPane.showMessageDialog(null, "Nome Modificado!");
									achei = true;
								}
							}
							if (achei == false) {
								throw new UsuarioException();
							}
						} catch (UsuarioException e) {
							JOptionPane.showMessageDialog(null, e.getMessage());
						}
						break;
					}

					if (opcaoEditar == 2) {
						try {
							for (int i = 0; i < listaUsuario.size(); i++) {
								if (listaUsuario.get(i).getCpf().equals(guardar)) {
									listaUsuario.get(i).setEndereco(
											JOptionPane.showInputDialog("Digite o novo endereço do usuario: "));
									JOptionPane.showMessageDialog(null, "Endereço Modificado");
									achei = true;
								}
							}
							if (achei == false) {
								throw new UsuarioException();
							}
						} catch (UsuarioException e) {
							JOptionPane.showMessageDialog(null, e.getMessage());
						}
						break;
					}
					if (opcaoEditar == 3) {
						try {
							for (int i = 0; i < listaUsuario.size(); i++) {
								if (listaUsuario.get(i).getCpf().equals(guardar)) {
									listaUsuario.get(i).setContato(
											JOptionPane.showInputDialog("Digite o novo contato do usuario: "));
									JOptionPane.showMessageDialog(null, "Contato Modificado");
									achei = true;
								}
							}
							if (achei == false) {
								throw new UsuarioException();
							}
						} catch (UsuarioException e) {
							JOptionPane.showMessageDialog(null, e.getMessage());
						}
						break;
					}
					break;
				// ------------------------------------------FIM DE
				// EDIÇÃO---------------------
				// ----------------------REMOÇÃO------------------------------------------------------
				case 3:
					achei = false;
					guardar = (JOptionPane.showInputDialog("Digite o cpf do Usuario que quer remover: "));
					try {
						for (int i = 0; i < listaUsuario.size(); i++) {
							if (listaUsuario.get(i).getCpf().equals(guardar)) {
								JOptionPane.showMessageDialog(null, listaUsuario.remove(i));
								JOptionPane.showMessageDialog(null, "Usuario Removido!");
								achei = true;
							}
						}
						if (achei == false) {
							throw new UsuarioException();
						}
					} catch (UsuarioException e) {
						JOptionPane.showMessageDialog(null, e.getMessage());
					}
					// --------------------------FIM DE REMOÇÃO --------------------------------
					break;
				}
				break;

			// -----------------------------FIM DAS OPÇÕES DE MANTER
			// USUARIO------------------------------------
			// ----------------------------------------- CADASTRAR
			// CARRO----------------------------
			case 2:
				int opcoesManterCarro = Integer.parseInt(JOptionPane
						.showInputDialog("" + "1 - Cadastar Carro:" + "\n2 - Editar Carro:" + "\n3 - Excluir Carro:"));

				switch (opcoesManterCarro) {
				case 1:

					Carro c = new Carro(); // Cadastrando carro Carro
					c.setMarca(JOptionPane.showInputDialog("Digite a marca do Carro: "));
					c.setModelo(JOptionPane.showInputDialog("Digite o modelo do Carro: "));
					c.setPlaca(JOptionPane.showInputDialog("Digite a placa do Carro: "));

					for (int i = 0; i < listaCarro.size(); i++) {
						try {
							while (listaCarro.get(i).getPlaca().equals(c.getPlaca())) {
								throw new CarroCadastradoException();// Lançando a exeção
							}
						} catch (CarroCadastradoException e) { // Tratando a exeção
							JOptionPane.showMessageDialog(null, e.getMessage());
							c.setPlaca(JOptionPane.showInputDialog("Digite outra placa: "));
						}
					}

					listaCarro.add(c);
					break;
				// -------------------------------EDITAR CARRO-----------------------
				case 2:
					achei = false;
					guardar = (JOptionPane.showInputDialog("Digite a placa  do Carro que quer editar: "));
					int opcaoEditar = Integer.parseInt(JOptionPane
							.showInputDialog("Digite o que você quer editar: " + "\n1 - Marca" + "\n2- Modelo")
							+ "\n3- Ano" + "\n4- Placa");
					if (opcaoEditar == 1) {
						try {
							for (int i = 0; i < listaCarro.size(); i++) {
								if (listaCarro.get(i).getPlaca().equals(guardar)) {
									listaCarro.get(i).setPlaca(JOptionPane.showInputDialog("Digite a nova marca: "));
									JOptionPane.showMessageDialog(null, "Marca Modificada!");
									achei = true;
								}
							}
							if (achei == false) {
								throw new CarroException();
							}
						} catch (CarroException e) {
							JOptionPane.showMessageDialog(null, e.getMessage());
						}
						break;
					}

					if (opcaoEditar == 2) {
						try {
							for (int i = 0; i < listaCarro.size(); i++) {
								if (listaCarro.get(i).getModelo().equals(guardar)) {
									listaCarro.get(i)
											.setModelo(JOptionPane.showInputDialog("Digite o novo Modelo do Carro: "));
									JOptionPane.showMessageDialog(null, "Modelo Modificado!");
									achei = true;
								}
							}
							if (achei == false) {
								throw new UsuarioException();
							}
						} catch (UsuarioException e) {
							JOptionPane.showMessageDialog(null, e.getMessage());
						}
						break;
					}
					if (opcaoEditar == 3) {
						try {
							for (int i = 0; i < listaCarro.size(); i++) {
								if (listaCarro.get(i).getPlaca().equals(guardar)) {
									listaCarro.get(i).setAno(Integer
											.parseInt(JOptionPane.showInputDialog("Digite o novo Ano do carro: ")));
									JOptionPane.showMessageDialog(null, "Ano Modificado!");
									achei = true;
								}
							}
							if (achei == false) {
								throw new UsuarioException();
							}
						} catch (UsuarioException e) {
							JOptionPane.showMessageDialog(null, e.getMessage());
						}
						break;
					}
					if (opcaoEditar == 4) {
						try {
							for (int i = 0; i < listaCarro.size(); i++) {
								if (listaCarro.get(i).getPlaca().equals(guardar)) {
									listaCarro.get(i)
											.setPlaca((JOptionPane.showInputDialog("Digite a nova Placa do Carro: ")));
									JOptionPane.showMessageDialog(null, "Placa Modificado!");
									achei = true;
								}
							}
							if (achei == false) {
								throw new UsuarioException();
							}
						} catch (UsuarioException e) {
							JOptionPane.showMessageDialog(null, e.getMessage());
						}
						break;
					}
					break;
				// ----------------------------REMOÇÃO CARRO---------------------
				case 3:
					achei = false;
					guardar = (JOptionPane.showInputDialog("Digite a placa do Carro que quer remover: "));
					try {
						for (int i = 0; i < listaCarro.size(); i++) {
							if (listaCarro.get(i).getPlaca().equals(guardar)) {
								JOptionPane.showMessageDialog(null, listaCarro.remove(i));
								JOptionPane.showMessageDialog(null, "Carro Removido!");
								achei = true;
							}
						}
						if (achei == false) {
							throw new UsuarioException();
						}
					} catch (UsuarioException e) {
						JOptionPane.showMessageDialog(null, e.getMessage());
					}
					break;
				}
				break;
			// -------------------------------------FIM DE REMOÇÃO
			// CARRO------------------------------------------
			// -------------------------------PESQUISAR USUARIO
			// ------------------------------------------------
			case 3: // Pesquisar Usuario
				achei = false;
				guardar = (JOptionPane.showInputDialog("Digite o cpf do Usuario que quer consultar: "));
				try {
					for (int i = 0; i < listaUsuario.size(); i++) {
						if (listaUsuario.get(i).getCpf().equals(guardar)) {
							JOptionPane.showMessageDialog(null, "\n Nome : " + listaUsuario.get(i).getNome()
									+ "\n Endereço: " + listaUsuario.get(i).getEndereco() + "\n Contato: "
									+ listaUsuario.get(i).getContato() + "\n Cpf: " + listaUsuario.get(i).getCpf());
							achei = true;
						}
					}
					if (achei == false) {
						throw new UsuarioException();
					}
				} catch (UsuarioException e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
				break;
			// -------------------FIM DE PESQUISA DE USUARIO-------------------------
			// ---------------------------------------PESQUISAR
			// CARRO------------------------------------------
			case 4:

				achei = false;
				guardar = (JOptionPane.showInputDialog("Digite a placa do Carro que quer consultar: "));
				try {
					for (int i = 0; i < listaCarro.size(); i++) {
						if (listaCarro.get(i).getPlaca().equals(guardar)) {
							JOptionPane.showMessageDialog(null,
									"\n Marca : " + listaCarro.get(i).getMarca() + "\n Modelo: "
											+ listaCarro.get(i).getModelo() + "\n Ano: " + listaCarro.get(i).getAno()
											+ "\n Placa: " + listaCarro.get(i).getPlaca());
							achei = true;
						}
					}
					if (achei == false) {
						throw new UsuarioException();
					}
				} catch (UsuarioException e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}

				break;
			// ---------------------------------------FIM DE PESQUISA DE
			// CARRO-----------------------------------------------
			// ------------------------------------- REALIZAR LOCAÇÕES
			// --------------------------------------------
			case 5:
				
				usuario = new Usuario();
				String guardarU = (JOptionPane.showInputDialog("Digite o cpf do Usuario que quer alocar: "));

				try {
					for (int i = 0; i < listaUsuario.size(); i++) {
						if (listaUsuario.get(i).getCpf().equals(guardarU)) {
							usuario = listaUsuario.get(i);
							acheiUsuario = true;
						}
					}

					for (int i = 0; i < listaCarro.size(); i++) {
						if (listaCarro.get(i) != null) {

							acheiCarro = true;
						}
					}

					if (acheiUsuario == true && acheiCarro == true) {
						JOptionPane.showMessageDialog(null, "Lista de Carros Cadastrados: \n");
						for (int i = 0; i < listaCarro.size(); i++) {
							if (listaCarro.get(i).isStatus() == false) {
								JOptionPane.showMessageDialog(null, "\n Marca : " + listaCarro.get(i).getMarca()
										+ "\n Modelo: " + listaCarro.get(i).getModelo() + "\n Ano: "
										+ listaCarro.get(i).getAno() + "\n Placa: " + listaCarro.get(i).getPlaca());
							} else {
								throw new CarroJaAlocadoException();
							}
						}
						guardar = (JOptionPane.showInputDialog("Digite a placa do Carro que quer Alocar: "));
						for (int i = 0; i < listaCarro.size(); i++) {
							if (listaCarro.get(i).getPlaca().equals(guardar)) {
								listaCarro.get(i).setStatus(true);
								usuario.setCarro(listaCarro.get(i));
							}
						}

						Locacao l = new Locacao(); // Criando usuario
						String dataini = JOptionPane.showInputDialog("Digite a data de inicio da locação: ");
						l.setDataInicio(dataini);
						String datafim = (JOptionPane.showInputDialog(null, "Digita a data de fim da locação: "));
						l.setDataFim(datafim);
						l.setPrecoLocacao(
								Double.parseDouble(JOptionPane.showInputDialog("Digite o valor da Locação: ")));

					} else if (acheiUsuario == false) {
						throw new UsuarioNaoCadastradoException();
					} else if (acheiCarro == false) {
						throw new CarroNaoCadastradoException();
					}
				} catch (UsuarioNaoCadastradoException e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
					break;
				} catch (CarroNaoCadastradoException e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				} catch (CarroJaAlocadoException e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
//---------------------------------------------------fim loca��o------------------------------------------------------------------
				
				// l.setContato(JOptionPane.showInputDialog("Digite o contato do Usuario: "));
				// for (int i = 0; i < listaCarro.size(); i++) {
				// try {
				// while (listaUsuario.get(i).getCpf().equals(l.getCpf())) {
				// throw new UsuarioCadastradoException();//Lançando a exeção
				// }
				// } catch (UsuarioCadastradoException e) { //Tratando a exeção
				// JOptionPane.showMessageDialog(null, e.getMessage());
				// u.setCpf(JOptionPane.showInputDialog("Digite outro cpf: "));
				// }
				// }

				// listaUsuario.add(u);

				break;

			case 6: 
				
				 guardarU = (JOptionPane.showInputDialog("Digite o cpf do Usuario que quer efetuar a devolu��o: "));

				try {
					for (int i = 0; i < listaUsuario.size(); i++) {
						if (listaUsuario.get(i).getCpf().equals(guardarU)) {
							usuario = listaUsuario.get(i);
							acheiUsuario = true;
						}
					}
					
					if (acheiUsuario == false) {
						throw new UsuarioNaoCadastradoException();
					}
					usuario.getCarro().setStatus(false);
					usuario.setCarro(null);
					JOptionPane.showMessageDialog(null, "Carro devolvido!");
				}catch (UsuarioNaoCadastradoException e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
				break;
				// case 7: // Listar pela ordem que foi inserida(PRONTO)

				// for (int i = 0; i < array.size(); i++) {
				// JOptionPane.showMessageDialog(null,
				// "\n Nome : " + array.get(i).getNome()
				// + "\n Apelido: " + array.get(i).getApelido()
				// + "\n Idade: " + array.get(i).getIdade()
				// + "\n Matricula: " + array.get(i).getMatricula());
				// }
				// break;
			}

		} while (opcao != 8);

	}
}
